package com.expense.exception;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandler {

	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<Map<String,String>> handleValidation(
	        MethodArgumentNotValidException ex) {

	    Map<String,String> errors = new HashMap<>();

	    ex.getBindingResult()
	      .getFieldErrors()
	      .forEach(error ->
	          errors.put(error.getField(),
	                     error.getDefaultMessage()));

	    return ResponseEntity.badRequest().body(errors);
	}


	@ExceptionHandler(ResourceNotFoundException.class)
    public ResponseEntity<ErorResponse> handleResourceNotFound(
            ResourceNotFoundException ex) {

        ErorResponse error = new ErorResponse(
                HttpStatus.NOT_FOUND.value(),
                ex.getMessage()
        );

        return ResponseEntity
                .status(HttpStatus.NOT_FOUND)
                .body(error);
    }

}
